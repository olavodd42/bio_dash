import dash
from dash import Dash
import dash_core_components as dcc
import dash_html_components as html
import dash.dependencies as dd
import pandas as pd
from plotly.subplots import make_subplots
import plotly.express as px

# Initialize Dash app
app = Dash(__name__)
server = app.server

# Load dataset
observations_df = pd.read_csv("observations.csv")
species_info_df = pd.read_csv("species_info.csv")

# Merge datasets
observations_df = observations_df.merge(species_info_df, on="scientific_name")


# Layout of the dashboard
app.layout = html.Div([
    html.H1("National Park Species Observations Dashboard", style={"textAlign": "center", "color": "#FFFFFF"}),
    
    # Dropdown to select park
    dcc.Dropdown(
        id="park-dropdown",
        options=[{"label": park, "value": park} for park in observations_df["park_name"].unique()],
        value=observations_df["park_name"].unique()[0],
        clearable=False,
        style={
            "backgroundColor": "#2A2A2A",     # fundo mais escuro para melhor contraste
            "color": "#FFFFFF",               # texto branco
            "fontSize": "16px",               # tamanho de fonte maior
            "padding": "10px",                # espaçamento interno para clareza
            "border": "1px solid #FFFFFF",    # borda visível para delimitar o menu
            "fontWeight": "bold",             # aumenta o peso da fonte
            "textAlign": "left"               # garante que o texto fique alinhado à esquerda
        }
    ),
    
    # Graph for observations
    dcc.Graph(id="observations-graph")
], style={"fontFamily": "Arial", "margin": "20px", "backgroundColor": "#1E1E1E", "color": "#FFFFFF", "padding": "20px", "borderRadius": "10px"})

# Callback to update graph based on dropdown selection
@app.callback(
    dd.Output("observations-graph", "figure"),
    [dd.Input("park-dropdown", "value")]
)
def update_graph(selected_park):
    filtered_df = observations_df[observations_df["park_name"] == selected_park].copy()

    # Replace missing conservation statuses with "Non-threatened"
    filtered_df["conservation_status"] = filtered_df["conservation_status"].fillna("Non-threatened")

    # Create subplots with dark theme
    fig = make_subplots(
        rows=1, cols=3,
        specs=[[{"type": "xy"}, {"type": "domain"}, {"type": "xy"}]],
        subplot_titles=(
            "Observations Count per Species",
            "Conservation Status Distribution",
            "Observations Count per Category"
        )
    )

    # Bar chart: observations per species
    bar_chart = px.bar(filtered_df, x="scientific_name", y="observations", color="conservation_status")
    for trace in bar_chart.data:
        fig.add_trace(trace, row=1, col=1)
    fig.update_traces(marker_line_width=0)

    # Pie chart: conservation status distribution
    status_counts = filtered_df.groupby("conservation_status")["observations"].sum().reset_index()
    status_counts.columns = ["status", "count"]
    pie_chart = px.pie(status_counts, names="status", values="count", color_discrete_sequence=px.colors.sequential.Purp_r)
    for trace in pie_chart.data:
        fig.add_trace(trace, row=1, col=2)

    # Bar chart: observations per category
    if "category" in filtered_df.columns and not filtered_df["category"].isnull().all():
        cat_counts = filtered_df.groupby("category")["observations"].sum().reset_index()
    else:
        cat_counts = pd.DataFrame({"category": ["No Data"], "observations": [0]})
    cat_chart = px.bar(cat_counts, x="category", y="observations", color="category", color_discrete_sequence=px.colors.qualitative.Set3)
    for trace in cat_chart.data:
        fig.add_trace(trace, row=1, col=3)

    fig.update_layout(
        title_text=f"Observations in {selected_park}",
        showlegend=True,
        paper_bgcolor="#1E1E1E",
        plot_bgcolor="#1E1E1E",
        font=dict(color="#FFFFFF")
    )

    return fig

# Run the dashboard
if __name__ == "__main__":
    app.run_server(debug=True)
